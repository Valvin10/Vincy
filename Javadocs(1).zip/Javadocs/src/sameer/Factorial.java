/**
 * 
 */
package sameer;

/**
 * @author aditi
 *
 */
public class Factorial {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		int count;
	      long factorial = 1;
	      
	      System.out.printf("%4s%30s\n", "Number", "Factorials");
	      for(count = 1; count <= 10; count++)
	      {
	         factorial *= count;
	         System.out.printf("%4d%,30d\n", count, factorial);
	         
	      }

	}

}
